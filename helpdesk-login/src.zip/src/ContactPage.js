import React from 'react';
import './styles/Chat.css';

const ContactPage = ({ onBack }) => {
  return (
    <div className="contact-page">
        <div className="contact-container">
            <button className="back-button" onClick={onBack}>Back</button>
            <h1>Contact Us</h1>
                <p>
                For assistance, please contact our helpdesk team:
                </p>
                <ul>
                <li><strong>Email:</strong> helpdesk@university.edu</li>
                <li><strong>Phone:</strong> +123-456-7890</li>
                <li><strong>Office Hours:</strong> Monday to Friday, 9:00 AM - 5:00 PM</li>
                </ul>
        </div>
    </div>
  );
};

export default ContactPage;
