import { useState } from 'react';
import '../styles/Chat.css';

const BookmarkedChats = ({ bookmarkedChats, toggleBookmarkedChats }) => {
  const [expandedIndex, setExpandedIndex] = useState(null); // State to track the expanded chat

  const handleToggle = (index) => {
    setExpandedIndex(expandedIndex === index ? null : index); // Toggle the expanded index
  };

  return (
    <div className="bookmark-page">
      <div className="bookmarked-chats-container">
        <button onClick={toggleBookmarkedChats} className="back-button">Back</button>
        <h1>Bookmarked Chats</h1>
        <p>Here you can view your bookmarked conversations.</p>
        <ul>
          {bookmarkedChats.map((chat, index) => (
            <li key={chat.id}>
              <button
                onClick={() => handleToggle(index)}
                className="collapsible-header"
              >
                <strong>You</strong> - {new Date(chat.bookmarkedAt).toLocaleString()}
              </button>
              {expandedIndex === index && (
                <div className="collapsible-content">
                  <ul>
                    {chat.messages.map((message, msgIndex) => (
                      <li key={msgIndex}>
                        <strong>{message.sender}:</strong> {message.text}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default BookmarkedChats;
